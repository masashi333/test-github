package jp.androidbook.myapp;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);

		if (savedInstanceState == null) {
			PlaceholderFragment fragment = new PlaceholderFragment();
			getFragmentManager().beginTransaction()
				.add(R.id.sec_container, fragment)
				.commit();
		}
	}


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.second, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_second, container, false);
			return rootView;
		}

		/* list 6-12
		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			final EditText edit1 = (EditText)activity.findViewById(R.id.sec_editText);
			Button button = (Button) activity.findViewById(R.id.sec_button);
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					FileInputStream stream = null;
					try {
						stream = activity.openFileInput("textdata.txt");
						byte[] buf = new byte[1024];
						stream.read(buf);
						edit1.setText(new String(buf));
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						try {
							stream.close();
							Toast toast = Toast.makeText(activity, "Loaded..",
								Toast.LENGTH_LONG);
							toast.show();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			});
		} */

		/* list 6-14 */
		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			final EditText edit1 = (EditText)activity.findViewById(R.id.sec_editText);
			Button button = (Button) activity.findViewById(R.id.sec_button);
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					FileInputStream stream = null;
					String path = Environment.getExternalStorageDirectory().getPath();
					try {
						stream = new FileInputStream(path + "/textdata.txt");
						byte[] buf = new byte[1024];
						stream.read(buf);
						edit1.setText(new String(buf));
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						try {
							stream.close();
							Toast toast = Toast.makeText(activity, "Loaded..",
								Toast.LENGTH_LONG);
							toast.show();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			});
		}
	}
}
