package jp.androidbook.myapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Camera;
import android.provider.MediaStore;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static android.hardware.Camera.PictureCallback;

public class SampleSurfaceView extends SurfaceView
	implements SurfaceHolder.Callback {

	private SurfaceHolder holder;

	public SampleSurfaceView(Context context) {
		super(context);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initial();
	}

	private void initial() {
		holder = this.getHolder();
	}

	@Override
	public void surfaceCreated(SurfaceHolder surfaceHolder) {

	}

	@Override
	public void surfaceChanged(SurfaceHolder surfaceHolder, int fp, int w, int h) {

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

	}

	@Override
	public boolean onTouchEvent(MotionEvent event){

		return true;
	}

}

