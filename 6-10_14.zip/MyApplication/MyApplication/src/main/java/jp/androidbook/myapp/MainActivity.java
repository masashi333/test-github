package jp.androidbook.myapp;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
	static final String MENU_ITEM = "menu item";
	private PlaceholderFragment fragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			fragment = new PlaceholderFragment();
			getFragmentManager().beginTransaction()
				.add(R.id.container, fragment)
				.commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		menu.add(MENU_ITEM);
		menu.add("SecondActivity");
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())) {}
		if ("SecondActivity".equals(item.getTitle())) {
			Intent intent = new Intent(this, SecondActivity.class);
			this.startActivity(intent);
		}
		return super.onOptionsItemSelected(item);
	}

	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container, false);
			return rootView;
		}

		/* list 6-11
		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			Button button = (Button) activity.findViewById(R.id.main_button);
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					EditText edit1 = (EditText)activity.findViewById(R.id.main_editText);
					String msg = edit1.getText().toString();
					FileOutputStream stream = null;
					try {
						stream = activity.openFileOutput("textdata.txt",
							Context.MODE_PRIVATE);
						stream.write(msg.getBytes());
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						try {
							stream.close();
							Toast toast = Toast.makeText(activity, "Saved..",
								Toast.LENGTH_LONG);
							toast.show();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			});
		} */

		/* list 6-13 */
		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			Button button = (Button) activity.findViewById(R.id.main_button);
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					EditText edit1 = (EditText)activity.findViewById(R.id.main_editText);

					String msg = edit1.getText().toString();
					FileOutputStream stream = null;
					String path = Environment.getExternalStorageDirectory().getPath();
					try {
						stream = new FileOutputStream(path + "/textdata.txt");
						stream.write(msg.getBytes());
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						try {
							stream.close();
							Toast toast = Toast.makeText(activity, "Saved..",
								Toast.LENGTH_LONG);
							toast.show();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			});
		}

	}

}
